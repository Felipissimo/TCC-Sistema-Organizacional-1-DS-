const perguntas = [
    "O ambiente de trabalho é respeitoso e colaborativo",
    "A comunicação interna é clara e eficiente",
    "Tenho os recursos necessários para realizar meu trabalho",
    "Sinto que meu trabalho é reconhecido",
    "Tenho boas oportunidades de desenvolvimento",
    "A liderança está aberta para ouvir os funcionários",
    "Existe equilíbrio entre trabalho e vida pessoal",
    "Sinto-me seguro para dar minha opinião",
    "As decisões da empresa são comunicadas de forma clara",
    "Eu recomendaria esta empresa como um bom lugar para trabalhar"
];

let notas = [];

function esconderTudo() {
    document.getElementById("telaPesquisa").classList.add("escondido");
    document.getElementById("telaQuestionario").classList.add("escondido");
    document.getElementById("telaGestor").classList.add("escondido");
    document.getElementById("telaDashboard").classList.add("escondido");
}

function mostrarInicio() {
    esconderTudo();
    document.getElementById("telaPesquisa").classList.remove("escondido");
}

function mostrarPesquisa() {
    esconderTudo();
    document.getElementById("telaQuestionario").classList.remove("escondido");
    notas = [];
    criarPerguntas();
}

function mostrarGestor() {
    esconderTudo();
    document.getElementById("telaGestor").classList.remove("escondido");
}

function criarPerguntas() {
    const area = document.getElementById("perguntas");
    area.innerHTML = "";

    for (let i = 0; i < perguntas.length; i++) {
        const notaInicial = notas[i] ?? 6;

        area.innerHTML +=
            '<div class="pergunta-card">' +
                '<div class="pergunta-titulo">' +
                    '<span>' + (i + 1) + '. ' + perguntas[i] + '</span>' +
                    '<span class="rosto">😐</span>' +
                '</div>' +
                '<input class="range" type="range" min="0" max="10" value="' + notaInicial + '" oninput="mudarNota(' + i + ', this.value)">' +
                '<div class="numeros"><span>0<br><small>Insatisfeito</small></span><span>1</span><span>2</span><span>3</span><span>4</span><span>5<br><small>Satisfeito</small></span><span>6</span><span>7</span><span>8</span><span>9</span><span>10<br><small>Muito satisfeito</small></span></div>' +
                '<div class="nota" id="nota' + i + '">' + notaInicial + '</div>' +
                '<div class="satisfacao" id="textoNota' + i + '">' + textoNota(notaInicial) + '</div>' +
            '</div>';
    }

    atualizarProgresso();
}

function mudarNota(indice, valor) {
    notas[indice] = Number(valor);
    document.getElementById("nota" + indice).innerText = valor;
    document.getElementById("textoNota" + indice).innerText = textoNota(Number(valor));
    atualizarProgresso();
}

function textoNota(nota) {
    if (nota <= 3) return "😟 Insatisfeito";
    if (nota <= 6) return "😐 Satisfeito";
    if (nota <= 8) return "🙂 Satisfeito";
    return "😄 Muito satisfeito";
}

function atualizarProgresso() {
    let respondidas = 0;
    for (let i = 0; i < perguntas.length; i++) {
        if (notas[i] != null) respondidas++;
    }

    if (respondidas === 0) respondidas = 1;
    document.getElementById("numeroPergunta").innerText = respondidas + " de 10";
    document.getElementById("barraProgresso").style.width = (respondidas * 10) + "%";
}

async function enviarPesquisa() {
    const botao = document.getElementById("botaoEnviar");
    const comentario = document.getElementById("comentario").value.trim();

    if (notas.length < 10 || notas.some(n => n == null)) {
        alert("Responda todas as perguntas antes de enviar.");
        return;
    }

    botao.disabled = true;
    botao.innerText = "Enviando...";

    try {
        const resposta = await fetch("api.php?action=salvar_pesquisa", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({notas, comentario})
        });

        const dados = await resposta.json();

        if (!resposta.ok || !dados.sucesso) {
            throw new Error(dados.mensagem || "Não foi possível salvar a pesquisa.");
        }

        alert("Pesquisa enviada com sucesso!");
        document.getElementById("comentario").value = "";
        mostrarInicio();
    } catch (erro) {
        alert(erro.message);
    } finally {
        botao.disabled = false;
        botao.innerText = "Enviar pesquisa";
    }
}

async function entrarGestor() {
    const email = document.getElementById("emailGestor").value.trim();
    const senha = document.getElementById("senhaGestor").value;
    const erro = document.getElementById("erroLogin");

    erro.innerText = "";

    try {
        const resposta = await fetch("api.php?action=login", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({email, senha})
        });

        const dados = await resposta.json();

        if (!resposta.ok || !dados.sucesso) {
            erro.innerText = dados.mensagem || "Email ou senha incorretos.";
            return;
        }

        esconderTudo();
        document.getElementById("telaDashboard").classList.remove("escondido");
        await carregarDashboard();
    } catch (e) {
        erro.innerText = "Erro ao conectar com o servidor.";
    }
}

async function carregarDashboard() {
    try {
        const resposta = await fetch("api.php?action=dashboard");
        const dados = await resposta.json();

        if (!resposta.ok || !dados.sucesso) {
            throw new Error(dados.mensagem || "Não foi possível carregar o dashboard.");
        }

        document.getElementById("mediaGeral").innerText = dados.media_geral.toFixed(1);
        document.getElementById("totalRespostas").innerText = dados.total_respostas;
        document.getElementById("taxaParticipacao").innerText = dados.taxa_participacao + "%";
        document.getElementById("ultimaAtualizacao").innerText = dados.ultima_atualizacao || "—";
        document.getElementById("dataAtualizacao").innerText = dados.ultima_atualizacao_completa || "Nenhuma resposta ainda";

        preencherPonto("critico1", dados.pontos_criticos[0]);
        preencherPonto("critico2", dados.pontos_criticos[1]);
        preencherPonto("forte1", dados.pontos_fortes[0]);
        preencherPonto("forte2", dados.pontos_fortes[1]);

        if (dados.total_respostas > 0) {
            document.querySelector(".tendencia").innerText =
                "↑ Dashboard atualizado com dados reais do banco";
        }
    } catch (erro) {
        alert(erro.message);
    }
}

function preencherPonto(prefixo, ponto) {
    if (!ponto) return;
    document.getElementById(prefixo + "Nome").innerText = ponto.nome;
    document.getElementById(prefixo + "Valor").innerText = ponto.media.toFixed(1);
}

async function sairDashboard() {
    await fetch("api.php?action=logout");
    mostrarInicio();
}

function menuDashboard(botao) {
    const botoes = document.getElementsByClassName("menu-item");
    for (let i = 0; i < botoes.length; i++) botoes[i].classList.remove("ativo");
    botao.classList.add("ativo");
}

function mostrarAviso(botao) {
    menuDashboard(botao);
    alert("Nesta versão do TCC, o Dashboard já está conectado ao banco. As telas de Resultados, Comentários e Relatórios podem ser implementadas depois.");
}
